grant insert,select,update on dueno to is274719;
grant insert,select,update on especialidad to is274719;
grant insert,select,update on especie to is274719;
grant insert,select,update on mascota to is274719;
grant insert,select,update on notas to is274719;
grant insert,select,update on veterinario to is274719;
grant insert,select,update on visitas to is274719;

grant insert,select,update on dueno to is274705;
grant insert,select,update on especialidad to is274705;
grant insert,select,update on especie to is274705;
grant insert,select,update on mascota to is274705;
grant insert,select,update on notas to is274705;
grant insert,select,update on veterinario to is274705;
grant insert,select,update on visitas to is274705;

grant insert,select,update on dueno to is274700;
grant insert,select,update on especialidad to is274700;
grant insert,select,update on especie to is274700;
grant insert,select,update on mascota to is274700;
grant insert,select,update on notas to is274700;
grant insert,select,update on veterinario to is274700;
grant insert,select,update on visitas to is274700;
commit;